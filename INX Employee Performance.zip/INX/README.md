Employee Performance Analysis The Data Science Projecr which is given here is an analysis of Employee Perforrmance. The goal of the project is to find the Performance Rating of the employees depending on features of the data, Such as Total Work Experience In Years, Employee Department, Gender, Experience Years In Current Role etc...,


The Goal and insights of the project as follows:
	1. Department Wise Performances
	2. Top 3 Important Factors affecting Employee Performance
	3. A Trained Model which can predict the employee performance based on factors as inputs.
	4. This will be used to hire Employees.
	5. Recommendations to improve the Employee Performance based on insights from analysis.
